def potencia(a,b):
	print("El resultado es: ", a**b)

def redondear(a):
	print("El numero es: ", round(a))