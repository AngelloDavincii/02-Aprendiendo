def sumar(a,b):
    print("El resultado es: ",a+b)

def restar(a,b):
    print("El resultado es: ",a-b)

def dot(a,b):
    print("El resultado es: ",a*b)

def dividir(a,b):
    print("El resultado es: ",a/b)

def potencia(a,b):
	print("El resultado es: ", a**b)

def redondear(a)
	print("El numero es: ", round(a))