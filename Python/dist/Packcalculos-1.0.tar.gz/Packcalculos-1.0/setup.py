from setuptools import setup

setup(
	name = "Packcalculos",
	version = "1.0",
	description = "Paquete de basicos",
	author = "Cuellarin",
	author_email = "angeld.cuellarb@gmail.com",
	packages = ["calculos","calculos.redondeo"]
	)